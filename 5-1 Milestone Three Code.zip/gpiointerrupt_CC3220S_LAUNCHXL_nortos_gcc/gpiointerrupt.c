/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>
#include <unistd.h> // For sleep functions

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/Timer.h>
#include "ti_drivers_config.h"
#include <ti/drivers/dpl/ClockP.h> // For ClockP_sleep

/* Morse code timing in microseconds */
#define DOT_DURATION 200000
#define DASH_DURATION 600000
#define BETWEEN_ELEMENTS 200000 // Time between dots/dashes within a letter
#define BETWEEN_LETTERS 600000  // Time between letters

// Function Prototypes
void initGPIO(void);
void initTimer(void);
void gpioButtonFxn0(uint_least8_t index);
void TickFct_SOS(void);
void blinkDot(void);
void blinkDash(void);
void delay(unsigned int microseconds);
volatile int messageState = 0; // 0 for SOS, 1 for OK
volatile int debounceFlag = 0; // Flag to prevent bounce-triggered repeats

void *mainThread(void *arg0) {
    // Initialize GPIO and Timer
    initGPIO();
    initTimer();

    // Main loop
    while (1) {
        sleep(1);
    }

    return NULL; // Return NULL to avoid compiler warning
}

// Initialize GPIOs for LEDs and Button
void initGPIO(void) {
    GPIO_init();

    // LEDs
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);

    // Button with interrupt
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);
}

void initTimer(void) {
    // Placeholder for timer initialization if needed
}

void gpioButtonFxn0(uint_least8_t index) {
    // Check if we're clear of debounce delay
    if (!debounceFlag) {
        debounceFlag = 1; // Set debounce flag
        if (messageState == 0) {
            TickFct_SOS();
            messageState = 1; // Set next state
        } else {
            TickFct_OK();
            messageState = 0; // Reset to initial state
        }
        ClockP_sleep(200); // Simple debounce delay
        debounceFlag = 0; // Clear debounce flag after delay
    }
}

// Blink SOS in Morse code
void TickFct_SOS(void) {
    // S: ...
    for (int i = 0; i < 3; i++) {
        blinkDot();
        delay(BETWEEN_ELEMENTS);
    }
    delay(BETWEEN_LETTERS - BETWEEN_ELEMENTS); // Adjust for last element pause

    // O: ---
    for (int i = 0; i < 3; i++) {
        blinkDash();
        delay(BETWEEN_ELEMENTS);
    }
    delay(BETWEEN_LETTERS - BETWEEN_ELEMENTS); // Adjust for last element pause

    // S: ...
    for (int i = 0; i < 3; i++) {
        blinkDot();
        delay(BETWEEN_ELEMENTS);
    }
}

// Blink OK in Morse code
void TickFct_OK(void) {
    // O: ---
    for (int i = 0; i < 3; i++) {
        blinkDash();
        delay(BETWEEN_ELEMENTS);
    }
    delay(BETWEEN_LETTERS - BETWEEN_ELEMENTS); // Adjust for last element pause

    // K: -�-
    blinkDash();
    delay(BETWEEN_ELEMENTS);
    blinkDot();
    delay(BETWEEN_ELEMENTS);
    blinkDash();
}

void blinkDot(void) {
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
    delay(DOT_DURATION);
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
}

void blinkDash(void) {
    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
    delay(DASH_DURATION);
    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
}

void delay(unsigned int microseconds) {
    usleep(microseconds); // Use usleep from unistd.h or equivalent delay function
}
